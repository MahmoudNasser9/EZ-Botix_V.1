# hal_keypad.py
from machine import Pin
import time

class MatrixKeypad:
    def __init__(self):
        # Explicit ESP32 pin maps for row outputs and column inputs
        self.row_pins = [Pin(13, Pin.OUT), Pin(12, Pin.OUT), Pin(14, Pin.OUT), Pin(27, Pin.OUT)]
        self.col_pins = [Pin(26, Pin.IN, Pin.PULL_DOWN), Pin(25, Pin.IN, Pin.PULL_DOWN), Pin(33, Pin.IN, Pin.PULL_DOWN), Pin(32, Pin.IN, Pin.PULL_DOWN)]
        
        self.layout = [
            ['1','2','3','A'],
            ['4','5','6','B'],
            ['7','8','9','C'],
            ['*','0','#','D']
        ]

    def read_key(self):
        """Scans the matrix and returns the pressed key string, or None"""
        for r_idx, row in enumerate(self.row_pins):
            row.value(1) # Drive current row HIGH
            for c_idx, col in enumerate(self.col_pins):
                if col.value() == 1: # Check which column reads HIGH
                    row.value(0)
                    return self.layout[r_idx][c_idx]
            row.value(0) # Pull row back LOW
        return None

    def wait_for_key(self, target_key):
        """Blocks the user execution thread until the specified key is hit"""
        while True:
            if self.read_key() == target_key:
                break
            time.sleep_ms(50) # Prevents core CPU starvation

# Instantiate a global instance for the system context
keypad = MatrixKeypad()